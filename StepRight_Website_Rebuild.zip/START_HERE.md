# StepRight Website Rebuild — Start Here

A responsive, accessible, single-page website for the StepRight 50-day career mentorship pilot, with separate starter privacy and programme terms pages.

## Files
- `index.html`: home page, design, mobile menu, expandable FAQs and WhatsApp links
- `privacy.html`: starter privacy notice — needs checking against actual practices
- `terms.html`: starter programme terms — needs founder approval, especially refunds

## Before publishing — important
1. **Approve the service scope**: This draft assumes **four one-to-one sessions including a mock interview**, a resume review with **up to two revision rounds**, selected application feedback and WhatsApp support during working hours. The uploaded materials did not establish precise numeric limits. Change these if you can't consistently deliver them.
2. **Approve the refund policy**: Draft proposes full refund within **48 hours after the first paid session**, if no subsequent service is used. The original website and Claude discussion described refund eligibility less precisely. You must decide the actual terms. Update `index.html` and `terms.html` consistently.
3. **Verify contact details**: `index.html` uses the WhatsApp number shown on the original uploaded PDF, `+91 9483835482`. To use a dedicated StepRight business number, replace the `WHATSAPP_NUMBER` constant in the script at the bottom of `index.html`, as well as the initial links (the script rewrites them on page load).
4. **Set up email**: No email address is displayed, because the uploaded website used `enquiries@stepright.org` while the revised draft proposed `enquiries@stepright.live`. Do not publish an address you haven't configured and tested. You may add a matching domain email when working.
5. **Check your public privacy preferences**: No founder name, portrait, resume, or invented testimonials appear. A potential client meets the actual mentor during a free call before payment.
6. **Pilot language**: The home page says up to 5 learners and ₹999, but doesn't display an invented seat counter or a made-up opening date. Remove or update the pilot messaging when the intake changes.
7. **Privacy/legal review**: Review both policy pages with an adviser or against actual practices and applicable Indian laws. Remove the editor-only notice at the bottom of each legal page after finalising them.
8. **Test payment operations**: Collect payments only after explaining the service and refund terms. Give receipts. Payment is not automated on this website.
9. **Test accessibility, links and forms**: No contact form is used; WhatsApp is the only active enquiry path. You can introduce a form later if there is a reliable backend.

## Suggested design system
- Main forest green: `#123b2f`
- Soft sage background: `#eef4e9`
- Warm cream background: `#fbfaf5`
- Accent gold: `#dfad66` (sparingly)
- Headlines: Manrope; body: DM Sans; sensible system fallbacks.
- Large breathing space; one key idea per section; expandable FAQs; mobile sticky enquiry button.

## Content decisions compared with the previous uploaded site
- Kept: the 50-day programme, five phases, student fit criteria, ₹999 pilot, honest commitment, initial conversation, WhatsApp enquiry.
- Combined: problem points, service contents, what mentor does, commitment, contact repetition.
- Removed: founder name/photo, invented status counters, duplicate 'what's included' and promise sections, redundant contact buttons, unclear 'BST' wording, misleading job-guarantee implication.
- Added: explicit call/review limits (proposed), a real three-step joining process, illustration of the student tracker marked *illustrative*, concrete refund window (proposed), functional privacy/terms pages.

## Publishing
Upload these three HTML pages together to any static web host, keeping the file names unchanged so the Privacy and Terms links work. Point your domain `stepright.live` to that host using your provider's DNS setup. No build tooling is needed.
