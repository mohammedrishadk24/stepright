# StepRight — Complete Website Copy (Draft)

**Navigation:** The 50-day plan · What's included · Who it's for · Pricing · FAQs · Talk to us

## Hero
**50-day career mentorship · Pilot programme**

# Your job search deserves a clearer plan.

Not sure where to start, what to improve, or why your applications aren't getting replies? StepRight offers practical, one-to-one guidance to help you move forward with more direction and confidence.

**[Check if StepRight is for me]** · [See the 50-day plan]

50 days of guidance · One-to-one support · ₹999 pilot fee · Up to 5 learners

## Sound familiar?
# Finding a job can feel confusing.

You've finished your studies or started applying. But it's hard to know what's working and what to do differently.

**Applications, no replies.** You've applied to several jobs but aren't sure why you're not hearing back.

**Not sure what to improve.** Your resume, LinkedIn profile or career direction might need work, but where do you begin?

**Interviews feel stressful.** You want to prepare properly and practise your answers before meeting employers.

You don't need another long list of tips. You need a plan you can actually follow — and honest feedback along the way.

## The programme
# 50 days. Five clear steps.

We'll work on the parts of your job search that need attention most. The timeline is a guide, so it can be adjusted to your goals and progress.

**Days 1–7 — Get clear on your direction.** Talk through your background, identify suitable roles, and review your resume and LinkedIn profile. *You leave with: a role shortlist, improvement priorities and a simple action plan.*

**Days 8–20 — Build your job-search toolkit.** Improve how you present your experience, set up a tracker and identify useful learning resources. *You leave with: a stronger profile and a practical application routine.*

**Days 21–35 — Apply with more purpose.** Find relevant openings, tailor selected applications and learn how to approach recruiters professionally. *You leave with: application and outreach templates you can use independently.*

**Days 36–45 — Prepare for interviews.** Practise common questions, explain your experience clearly and receive feedback on your answers. *You leave with: an interview-preparation checklist and feedback.*

**Days 46–50 — Review and move forward.** Look at your progress, understand what's still challenging and plan your next month of applications. *You leave with: a career progress summary and your next steps.*

**Already ready to apply?** You won't have to wait until Day 21. We can adapt the order to what you need most.

## What you receive
# Practical help, not just advice.

You'll get personal feedback, useful tools and guidance that helps you do the work yourself.

- Four scheduled one-to-one sessions, including a mock interview.
- Resume feedback with up to two revision rounds.
- LinkedIn profile feedback and a checklist.
- An application tracker and outreach templates.
- Feedback on selected applications and messages.
- WhatsApp questions and weekly progress check-ins.

**You'll do the work. We'll help you do it better.** The goal isn't to depend on a mentor forever. It's to develop the confidence and habits to continue your job search on your own.

Plan to set aside around 1–2 hours a day for applications, learning and practice. Mentorship support is available during working hours.

## A good match matters
# Is StepRight right for you?

We want you to join only if the programme can genuinely help with your goals.

**It could be a good fit if you:** are a recent graduate or early-career job seeker; need direction, structure or feedback; want to improve your resume, LinkedIn or interviews; and can make time to apply consistently.

**It may not be right if you:** expect a guaranteed job, referral or placement; want someone else to submit applications for you; need specialised exam or regulated-profession preparation; or cannot commit time to your search.

## Meet StepRight
# Guidance that's personal, practical and honest.

StepRight grew from helping students and early-career job seekers with resumes, applications and interview preparation. We wanted to make that kind of one-to-one support more structured and accessible.

The programme is currently run by one mentor. You'll have a chance to speak with your mentor before you decide to enrol.

**What we stand for:** No false promises. Feedback you can use. Your details handled with care. A conversation before commitment.

**A glimpse of your progress tracker:** Display a fictional example marked *Illustrative example*, with target role, next action and weekly focus.

## Pilot batch pricing
# A small start, with personal attention.

We're starting with up to five participants so we can give meaningful feedback and improve the programme based on the first cohort's experience.

**StepRight 50-day mentorship — ₹999 total (pilot price).**

This is a one-time programme fee, not a monthly subscription. No percentage of your future salary is charged.

Includes the 50-day guided plan, four scheduled one-to-one sessions, resume and LinkedIn feedback, selected application feedback, templates, a progress tracker, a mock interview and WhatsApp questions during working hours.

**[Ask about joining]**

**Start with a free chat.** Pay only after we've discussed whether the programme fits your needs. If you enrol and decide it's not right after your first mentoring session, you can request a full refund within 48 hours of that session, before further support is used. [Read the full terms]

**How to join**

1. **Say hello.** Message us on WhatsApp about your background and the roles you're considering.
2. **Have a free chat.** We'll discuss your goals and explain how the mentorship works.
3. **Enrol and begin.** If it's a good fit, complete payment and book your first mentoring session.

## FAQs
**Do I need any work experience?** No. The programme is designed for recent graduates and early-career job seekers. We'll help you present your projects, education, volunteering and relevant skills honestly.

**Will StepRight find me a job?** No. We are a mentorship service, not a recruitment agency. We help you improve your approach, but job offers, interviews and hiring decisions are made by employers.

**What if I already have a resume?** That's useful. We'll review what you have and focus on the changes that matter for your target roles. You won't have to start from scratch.

**How much time will I need?** Try to set aside 1–2 hours a day for your applications, learning and practice. We'll schedule the mentoring calls together.

**Do I need to buy courses or extra services?** No paid courses are required. If we identify a skill gap, we'll suggest suitable free learning resources first.

**When can I message my mentor?** For quick questions, you can use WhatsApp during the 50-day programme. Support is handled on working days, Monday–Friday, 9 am–6 pm IST; it isn't 24/7 instant support.

**What happens after the 50 days?** You'll receive a short progress summary and a plan for your next steps. The included one-to-one mentoring and WhatsApp support end when the programme finishes.

**What if I change my mind?** You can have a free suitability conversation before paying. A full refund can be requested within 48 hours of the first paid mentoring session, provided you haven't used further support. Please read the complete refund terms.

## Final invitation
# You don't have to figure out your next move alone.

Tell us a little about where you are in your job search. We'll help you decide whether StepRight is the right kind of support.

**[Start a WhatsApp conversation]**

Free initial conversation · No payment needed

## Footer
**StepRight.** Practical career mentorship. A clearer plan, honest feedback and support to move forward.

Programme · Pricing · FAQs · Privacy · Programme terms · WhatsApp

Mentorship support: Monday–Friday, 9:00–18:00 IST · Based in India.

---

**Founder approval needed before publishing:** Four sessions including the mock interview, two resume revision rounds, WhatsApp support hours, and the 48-hour post-first-session refund policy are recommendations; they need your confirmation. The pilot's up-to-five places and ₹999 price come from your original documents. No founder name or public photo is used.
